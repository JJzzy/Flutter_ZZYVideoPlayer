//
//  GLRender.h
//  EZViewer
//
//  Created by zhuzhengyi on 2020/4/2.
//  Copyright © 2020 uniview. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Flutter/Flutter.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^FrameUpdateCallback)(void);

@interface GLRender : NSObject <FlutterTexture>

- (instancetype)initWithFrameUpdateCallback:(FrameUpdateCallback)callback;

- (void)startRender;

- (void)update;

- (void)yuvPixelBufferWithData:(void *)dataFrame width:(int)w heigth:(int)h;

@end

NS_ASSUME_NONNULL_END
