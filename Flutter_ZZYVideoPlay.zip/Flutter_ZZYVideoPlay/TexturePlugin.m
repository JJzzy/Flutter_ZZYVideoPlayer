//
//  TexturePlugin.m
//  EZViewer
//
//  Created by zhuzhengyi on 2020/4/2.
//  Copyright © 2020 uniview. All rights reserved.
//

#import "TexturePlugin.h"

@interface TexturePlugin ()

@property (nonatomic, strong) NSObject<FlutterTextureRegistry> *textures;

@end

@implementation TexturePlugin

- (instancetype) initWithTextures:(NSObject<FlutterTextureRegistry> *)textures {
    if (self = [super init]) {
        _textures = textures;
    }
    return self;
}

+ (TexturePlugin *)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
    
    FlutterMethodChannel *channel = [FlutterMethodChannel methodChannelWithName:@"opengl_texture" binaryMessenger:[registrar messenger]];
    
    TexturePlugin *instance = [[TexturePlugin alloc] initWithTextures:registrar.textures];
    
    [registrar addMethodCallDelegate:instance channel:channel];
    
    return instance;
}

- (void)handleMethodCall:(FlutterMethodCall*)call result:(FlutterResult)result
{
    if ([call.method isEqualToString:@"newTexture"]) {
  
        __block int64_t textureId = 0;
        
        __weak typeof(self) wself = self;
        _glRender = [[GLRender alloc] initWithFrameUpdateCallback:^{
            [wself.textures textureFrameAvailable:textureId];
        }];
        textureId = [_textures registerTexture:_glRender];
        
        [_glRender startRender];
        
        result(@(textureId));
    }
}

@end
