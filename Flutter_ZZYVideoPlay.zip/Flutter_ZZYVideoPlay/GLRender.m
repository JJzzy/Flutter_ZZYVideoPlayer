//
//  GLRender.m
//  EZViewer
//
//  Created by zhuzhengyi on 2020/4/2.
//  Copyright © 2020 uniview. All rights reserved.
//

#import "GLRender.h"
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#import <CoreVideo/CoreVideo.h>
#import <UIKit/UIKit.h>
#import "libyuv.h"

@implementation GLRender
{
    FrameUpdateCallback _callback;
    EAGLContext *_context;
    CGSize _size;
    CVOpenGLESTextureCacheRef _textureCache;
    CVOpenGLESTextureRef _texture;
    CVPixelBufferRef _target;
    
    GLuint _program;
    
    GLuint _frameBuffer;
    
    CADisplayLink *_displayLink;

    int _lastUpdateTs;
    GLfloat _angle;
    CFAbsoluteTime startTime;
}

- (CVPixelBufferRef)copyPixelBuffer {
    //实现FlutterTexture协议的接口，每次flutter是直接读取我们映射了纹理的pixelBuffer对象
    CVBufferRetain(_target);
    return _target;
}

- (instancetype)initWithFrameUpdateCallback:(FrameUpdateCallback)callback
{
    if (self = [super init]) {
        _callback = callback;
        _size = CGSizeMake(2000, 2000);
        
        [self initGL];
        [self loadShaders];
    }
    return self;
}

- (void)initGL {
    _context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    [EAGLContext setCurrentContext:_context];
    // 先调用函数创建共享内存的pixelBuffer和texture对象
    [self createCVBufferWith:&_target withOutTexture:&_texture];
        
    // 创建帧缓冲区
    glGenFramebuffers(1, &_frameBuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, _frameBuffer);
    
    // 将纹理附加到帧缓冲区上
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, CVOpenGLESTextureGetName(_texture), 0);
    
    glViewport(0, 0, _size.width, _size.height);
    
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatus(GL_FRAMEBUFFER));
    }
}

- (void)createCVBufferWith:(CVPixelBufferRef *)target withOutTexture:(CVOpenGLESTextureRef *)texture {
    // 创建纹理缓存池，这个不是重点
    CVReturn err = CVOpenGLESTextureCacheCreate(kCFAllocatorDefault, NULL, _context, NULL, &_textureCache);
    if (err) {
        return;
    }
    
    CFDictionaryRef empty;
    CFMutableDictionaryRef attrs;
    empty = CFDictionaryCreate(kCFAllocatorDefault, NULL, NULL, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    attrs = CFDictionaryCreateMutable(kCFAllocatorDefault, 1, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    
    // 核心参数是这个，共享内存必须要设置这个kCVPixelBufferIOSurfacePropertiesKey
    CFDictionarySetValue(attrs, kCVPixelBufferIOSurfacePropertiesKey, empty);
    // 分配pixelBuffer对象的内存，注意flutter需要的是BGRA格式
    CVPixelBufferCreate(kCFAllocatorDefault, _size.width, _size.height, kCVPixelFormatType_32BGRA, attrs, target);
    // 映射上面的pixelBuffer对象到一个纹理上
    CVOpenGLESTextureCacheCreateTextureFromImage(kCFAllocatorDefault, _textureCache, *target, NULL, GL_TEXTURE_2D, GL_RGBA, _size.width, _size.height, GL_BGRA, GL_UNSIGNED_BYTE, 0, texture);
    
    CFRelease(empty);
    CFRelease(attrs);
}

- (void)deinitGL {
    glDeleteFramebuffers(1, &_frameBuffer);
    CFRelease(_target);
    CFRelease(_textureCache);
    CFRelease(_texture);
}

- (void)startRender
{
//    if (!_displayLink) {
//        _displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(update)];
//        _displayLink.preferredFramesPerSecond = 60;
//        [_displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
//    }
    
//    [self update];
}

- (void)update
{
    [EAGLContext setCurrentContext:_context];
        
    NSTimeInterval now = CFAbsoluteTimeGetCurrent();
    if (now - _lastUpdateTs <= 3) { // 3秒转一个圈
        _angle = ((now - _lastUpdateTs) / 1.5 - 1) * M_PI * 2;
    } else {
        _angle = -M_PI;
        _lastUpdateTs = now;
    }
            
    glClearColor(0.2, 0.2, 0.2, 1);
    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(_program);
    
    GLuint angleUniformLocation = glGetUniformLocation(_program, "angle");
    glUniform1f(angleUniformLocation, _angle);
    
    [self drawTriangle];
    
    glFlush();
    
    _callback();
}

- (void)drawTriangle {
    static GLfloat trangleData[] = {
        0.0f,   0.5f,   0.0f,
        -0.5f,  -0.5f,  0.0f,
        0.5f,   -0.5f,  0.0f,
    };
    
    GLuint positionAttribLocation = glGetAttribLocation(_program, "position");
    glEnableVertexAttribArray(positionAttribLocation);
    
    glVertexAttribPointer(positionAttribLocation, 3, GL_FLOAT, GL_FALSE, 3*sizeof(GLfloat), trangleData);
    
    glDrawArrays(GL_TRIANGLES, 0, 3);
}

#pragma mark - shader compilation
- (BOOL)loadShaders
{
    GLuint vertShader, fragShader;
    NSString *vertShaderPathname, *fragShaderPathname;
    
    _program = glCreateProgram();
    
    vertShaderPathname = [[NSBundle mainBundle] pathForResource:@"Shader" ofType:@"vsh"];
    if (![self compileShader:&vertShader type:GL_VERTEX_SHADER file:vertShaderPathname]) {
        NSLog(@"failed to compile vertex shader");
        return NO;
    }
    
    fragShaderPathname = [[NSBundle mainBundle] pathForResource:@"Shader" ofType:@"fsh"];
    if (![self compileShader:&fragShader type:GL_FRAGMENT_SHADER file:fragShaderPathname]) {
        NSLog(@"failed to compile fragment shader");
        return NO;
    }
    
    glAttachShader(_program, vertShader);
    glAttachShader(_program, fragShader);
    
    if (![self linkProgram:_program]) {
        NSLog(@"failed to link program: %d", _program);
        
        if (vertShader) {
            glDeleteShader(vertShader);
            vertShader = 0;
        }
        if (fragShader) {
            glDeleteShader(fragShader);
            fragShader = 0;
        }
        if (_program) {
            glDeleteProgram(_program);
            _program = 0;
        }
        return NO;
    }
    
    if (vertShader) {
       glDetachShader(_program, vertShader);
       glDeleteShader(vertShader);
    }
    if (fragShader) {
       glDetachShader(_program, fragShader);
       glDeleteShader(fragShader);
    }
    
    NSLog(@"load shaders succ");
    return YES;
}

- (BOOL)compileShader:(GLuint *)shader type:(GLenum)type file:(NSString *)file
{
    GLint status;
    const GLchar *source;
    
    source = (GLchar*)[[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil] UTF8String];
    if (!source) {
        NSLog(@"failed to load shader. type: %i", type);
        return NO;
    }
    
    *shader = glCreateShader(type);
    glShaderSource(*shader, 1, &source, NULL);
    glCompileShader(*shader);
    
    #if defined(DEBUG)
       GLint logLength;
       glGetShaderiv(*shader, GL_INFO_LOG_LENGTH, &logLength);
       if (logLength > 0) {
          GLchar *log = (GLchar *)malloc(logLength);
          glGetShaderInfoLog(*shader, logLength, &logLength, log);
          NSLog(@"Shader compile log:\n%s", log);
          free(log);
       }
    #endif
    
    glGetShaderiv(*shader, GL_COMPILE_STATUS, &status);
    if (status == 0) {
       glDeleteShader(*shader);
       return NO;
    }
    
    return YES;
}

- (BOOL)linkProgram:(GLuint)prog
{
    GLint status;
    glLinkProgram(prog);
    
    glGetProgramiv(prog, GL_LINK_STATUS, &status);
    if (status == 0) {
       return NO;
    }
    
    return YES;
}

- (BOOL)validateProgram:(GLuint)prog
{
    GLint logLength, status;
    glValidateProgram(prog);
    glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &logLength);
    if (logLength > 0) {
        GLchar *log = (GLchar *)malloc(logLength);
        glGetProgramInfoLog(prog, logLength, &logLength, log);
        NSLog(@"program validate log : \n%s", log);
        free(log);
    }
    
    glGetProgramiv(prog, GL_VALIDATE_STATUS, &status);
    if (status == 0) {
        return NO;
    }
    
    return YES;
}





/****************************************   分割线，在Flutter中处理和显示EZView的YUV数据  ******************************************/

/*
 kCVPixelFormatType类型的含义
 kCVPixelFormatType_{长度|序列}{颜色空间}{Planar|BiPlanar}{VideoRange|FullRange}
 Planar: 平面；BiPlanar：双平面
 平面／双平面主要应用在yuv上。uv分开存储的为Planar，反之是BiPlanar。所以，kCVPixelFormatType_420YpCbCr8PlanarFullRange是420p，kCVPixelFormatType_420YpCbCr8BiPlanarFullRange是nv12.
 */
static OSType KVideoPixelFormatType = kCVPixelFormatType_420YpCbCr8BiPlanarFullRange;

 
- (void)yuvPixelBufferWithData:(void *)dataFrame width:(int)w heigth:(int)h {
    startTime = CFAbsoluteTimeGetCurrent();
    //YUV数据字符
    unsigned char *buffer = (unsigned char*)dataFrame;
    
    /******
//    //数据是黑白的，采用下面libyuv的方式转换则正常
//    CVPixelBufferRef getCroppedPixelBuffer = [self copyDataFromBuffer:buffer toYUVPixelBufferWithWidth:w Height:h];
     ******/
    
    //使用libyuv库的 I420ToNV12() 方法转化数据正常。将 YUV420的char 转化为 CVPixelBuffer 类型的帧数据
    CVPixelBufferRef getOriginalPixelBuffer = [self yuv420FrameToPixelBuffer:buffer width:w height:h];
    if (!getOriginalPixelBuffer) {
        return;
    }
    //压缩数据
    CMSampleBufferRef sampleBuffer = [self pixelBufferToSampleBuffer:getOriginalPixelBuffer];
    if (!sampleBuffer) {
        return;
    }
    //通过libyuv库的方法，将sampleBuffer 转换为 32BGRA格式的CVPixelBuffer
    CVPixelBufferRef finalPixelBuffer = [self convertVideoSmapleBufferToBGRAData:sampleBuffer];
    if (!finalPixelBuffer) {
        return;
    }
    CFRelease(getOriginalPixelBuffer);//释放
    //实时更新帧数据，释放上一帧的内存，指向新一帧画面的内存
    CFRelease(_target);
    _target = finalPixelBuffer;
    //实时回调，使得Flutter侧能够实时共享到最新的texture
    _callback();
    
    CFAbsoluteTime currentTime = CFAbsoluteTimeGetCurrent();
    CFAbsoluteTime dxTime = currentTime - startTime;
    NSLog(@"zhuzhengyi:Live Pixelbuffer use time:%f", dxTime*1000);
}

/********************     YUV420 数据转 nv12的CVPixelBufferRef(本质上还是YUV420数据)     **********************/
- (CVPixelBufferRef)yuv420FrameToPixelBuffer:(const unsigned char*)yuv420Frame width:(int)frameWidth height:(int)frameHeight
{
    if (yuv420Frame == nil) {
        return NULL;
    }

    CVPixelBufferRef pixelBuffer =  NULL ;
    NSDictionary *pixelBufferAttributes = [NSDictionary dictionaryWithObjectsAndKeys:[NSDictionary dictionary], (id)kCVPixelBufferIOSurfacePropertiesKey, nil];
    //为YUV420格式的CVPixelBuffer分配内存
    CVReturn result = CVPixelBufferCreate(kCFAllocatorDefault, frameWidth, frameHeight, kCVPixelFormatType_420YpCbCr8BiPlanarFullRange, (__bridge  CFDictionaryRef)pixelBufferAttributes, &pixelBuffer);
    if (result != kCVReturnSuccess) {
        NSLog(@"ZZY:[yuv420FrameToPixelBuffer] Failed to create pixel buffer: %d", result);
        return NULL;
    }
    //加锁
    result = CVPixelBufferLockBaseAddress(pixelBuffer, 0);
    if (result != kCVReturnSuccess) {
        CFRelease(pixelBuffer);
        NSLog(@"ZZY:[yuv420FrameToPixelBuffer] Failed to lock base address: %d", result);
        return  NULL;
    }
    //获取pixelBuffer中的Y数据
    uint8 *dstY = (uint8 *)CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0);
    int dstStrideY = (int)CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer, 0);
    //获取pixelBuffer中的UV数据
    uint8* dstUV = (uint8*)CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 1);
    int dstStrideUV = ( int )CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer, 1);
    
    UInt8 *_planeData[3];
    NSUInteger _stride[3];
    uint8 *_data = (uint8 *)yuv420Frame;
    
    _planeData[0] = _data;//y数据
    _planeData[1] = _planeData[0] + frameWidth * frameHeight;//u
    _planeData[2] = _planeData[1] + frameWidth * frameHeight / 4;//v
    _stride[0] = frameWidth;
    _stride[1] = frameWidth >> 1;
    _stride[2] = frameWidth >> 1;
    //使用libyuv库的方法进行数据转换
    int ret = I420ToNV12(_planeData[0], ( int )_stride[0],
                         _planeData[1], ( int )_stride[1],
                         _planeData[2], ( int )_stride[2],
                         dstY, dstStrideY,
                         dstUV, dstStrideUV,
                         frameWidth, frameHeight);
    //解锁
    CVPixelBufferUnlockBaseAddress(pixelBuffer, 0);
    if (ret) {
        NSLog(@"ZZY:[yuv420FrameToPixelBuffer] Error converting yuv420 VideoFrame to NV12: %d", result);
        CFRelease(pixelBuffer);
        return NULL;
    }
    
    return pixelBuffer;
}

//数据压缩
- (CMSampleBufferRef)pixelBufferToSampleBuffer:(CVPixelBufferRef)pixelBuffer {

    CMSampleBufferRef sampleBuffer;
    CMTime frameTime = CMTimeMakeWithSeconds([[NSDate  date] timeIntervalSince1970], 1000000000);
    CMSampleTimingInfo timing = {frameTime, frameTime, kCMTimeInvalid};
    CMVideoFormatDescriptionRef videoInfo =  NULL ;
    CMVideoFormatDescriptionCreateForImageBuffer(NULL , pixelBuffer, &videoInfo);
    OSStatus status = CMSampleBufferCreateForImageBuffer(kCFAllocatorDefault, pixelBuffer, true ,  NULL , NULL , videoInfo, &timing, &sampleBuffer);
    //释放资源
    CFRelease(pixelBuffer);
    if (videoInfo) {
        CFRelease(videoInfo);
    }
    if (status != noErr) {
        NSLog(@"ZZY:[pixelBufferToSampleBuffer] Failed to create sample buffer with error %d.", ( int )status);
        return NULL;
    }
    
    return  sampleBuffer;
}

//转化_为kCVPixelFormatType_32BGRA类型数据（使Flutter的skia引擎可以绘制）
- (CVPixelBufferRef)convertVideoSmapleBufferToBGRAData:(CMSampleBufferRef)videoSample{

    //CVPixelBufferRef是CVImageBufferRef的别名，两者操作几乎一致。
    //获取CMSampleBuffer的图像地址
    CVImageBufferRef pixelBuffer = CMSampleBufferGetImageBuffer(videoSample);
    //VideoToolbox解码后的图像数据并不能直接给CPU访问，需先用CVPixelBufferLockBaseAddre()锁定地址才能从主存访问，否则调用CVPixelBufferGetBaseAddressOfPlane等函数则返回NULL或无效值。值得注意的是，CVPixelBufferLockBaseAddress自身的调用并不消耗多少性能，一般情况，锁定之后，往CVPixelBuffer拷贝内存才是相对耗时的操作，比如计算内存偏移。_
    CVPixelBufferLockBaseAddress(pixelBuffer, 0);
    //图像宽度（像素）
    size_t pixelWidth = CVPixelBufferGetWidth(pixelBuffer);
    //图像高度（像素）
    size_t pixelHeight = CVPixelBufferGetHeight(pixelBuffer);
    //获取CVImageBufferRef中的y数据
    uint8_t *y_frame = (unsigned char *)CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0);
    //获取CMVImageBufferRef中的uv数据
    uint8_t *uv_frame =(unsigned char *) CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 1);
    
    // 创建一个空的32BGRA格式的CVPixelBufferRef
    NSDictionary *pixelAttributes = @{(id)kCVPixelBufferIOSurfacePropertiesKey : @{}};
    CVPixelBufferRef pixelBuffer1 = NULL;
    CVReturn result = CVPixelBufferCreate(kCFAllocatorDefault, pixelWidth, pixelHeight, kCVPixelFormatType_32BGRA, (__bridge CFDictionaryRef)pixelAttributes, &pixelBuffer1);
    if (result != kCVReturnSuccess) {
        NSLog(@"ZZY:[convertVideoSmapleBufferToBGRAData] Unable to create cvpixelbuffer %d", result);
        return NULL ;
    }

    CVPixelBufferUnlockBaseAddress(pixelBuffer, 0);
    result = CVPixelBufferLockBaseAddress(pixelBuffer1, 0);
    if (result != kCVReturnSuccess) {
        CFRelease(pixelBuffer1);
        NSLog(@"ZZY:[convertVideoSmapleBufferToBGRAData] Failed to lock base address: %d", result);
        return NULL ;
    }
    // 得到新创建的CVPixelBufferRef中 rgb数据的首地址
    uint8_t *rgb_data = CVPixelBufferGetBaseAddress(pixelBuffer1);
    // 使用libyuv为rgb_data写入数据，将NV12转换为BGRA
    int  ret = NV12ToARGB(y_frame, pixelWidth, uv_frame, pixelWidth, rgb_data, pixelWidth * 4, pixelWidth, pixelHeight);
    if  (ret) {
        NSLog(@"ZZY:[convertVideoSmapleBufferToBGRAData] Error converting NV12 VideoFrame to BGRA: %d", result);
        CFRelease(pixelBuffer1);
        return NULL ;
    }
    CVPixelBufferUnlockBaseAddress(pixelBuffer1, 0);
    
    return  pixelBuffer1;
}

///**********************  同yuv420FrameToPixelBuffer:方法想要达到的目的相同，只不过没有使用libyuv的方法，因此转换后的数据是黑白的，暂时弃用  ***************/
//- (CVPixelBufferRef)copyDataFromBuffer:(const unsigned char*)buffer toYUVPixelBufferWithWidth:(size_t)w Height:(size_t)h
//{
//    NSDictionary *pixelBufferAttributes = [NSDictionary dictionaryWithObjectsAndKeys:[NSDictionary dictionary], kCVPixelBufferIOSurfacePropertiesKey, nil];
//    CVPixelBufferRef pixelBuffer;
//    CVReturn result = CVPixelBufferCreate(NULL, w, h, KVideoPixelFormatType, (__bridge CFDictionaryRef)(pixelBufferAttributes), &pixelBuffer);
//    if (result != kCVReturnSuccess) {
//        NSLog(@"zhuzhengyi:YUV change to CVPixe failed");
//        return NULL;
//    }
//
//    CVPixelBufferLockBaseAddress(pixelBuffer, 0);
//
//    const unsigned char *src = buffer;
//
//    size_t d = CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer, 0);
//    unsigned char *dst = (unsigned char *)CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 0);
//    for (unsigned int rIdx = 0; rIdx < h; ++rIdx, dst += d, src += w) {
//        memcpy(dst, src, w);
//    }
//
//    d = CVPixelBufferGetBytesPerRowOfPlane(pixelBuffer, 1);
//    dst = (unsigned char *)CVPixelBufferGetBaseAddressOfPlane(pixelBuffer, 1);
//    h = h >> 1;
//    for (unsigned int rIdx = 0; rIdx < h; ++rIdx, dst += d, src += w) {
//        memcpy(dst, src, w);
//    }
//
//    CVPixelBufferUnlockBaseAddress(pixelBuffer, 0);
//
//    return pixelBuffer;
//}


@end
