//
//  TexturePlugin.h
//  EZViewer
//
//  Created by zhuzhengyi on 2020/4/2.
//  Copyright © 2020 uniview. All rights reserved.
//

#import <Flutter/Flutter.h>
#import "GLRender.h"

NS_ASSUME_NONNULL_BEGIN

@interface TexturePlugin : NSObject <FlutterPlugin>

@property (nonatomic, strong) GLRender *glRender;

+ (TexturePlugin *)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar;

@end

NS_ASSUME_NONNULL_END
